// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;
import "./PaymentEscrow.sol";

contract DisputeBoard {
    RoleRegistry public immutable registry;
    PaymentEscrow public immutable escrow;
    mapping(uint256=>bytes32) public reasons;
    mapping(uint256=>bytes32) public rulings;
    event DisputeOpened(uint256 indexed id,address indexed actor,bytes32 reason);
    event DisputeResolved(uint256 indexed id,address indexed auditor,uint256 providerAmount,bytes32 ruling);
    constructor(address access,address payments) {
        registry=RoleRegistry(access); escrow=PaymentEscrow(payments);
        require(address(escrow.registry())==access,"Registry mismatch");
    }
    function openDispute(uint256 id,bytes32 reason) external {
        require(reason!=0 && reasons[id]==0,"Invalid reason");
        escrow.flagDispute(id,msg.sender); reasons[id]=reason;
        emit DisputeOpened(id,msg.sender,reason);
    }
    function resolveDispute(uint256 id,uint256 providerAmount,bytes32 ruling) external {
        PaymentEscrow.Agreement memory a=escrow.getAgreement(id);
        // The auditor selected in the original agreement keeps jurisdiction even if removed
        // from the registry later; removal only prevents assignment to new agreements.
        require(msg.sender==a.auditor && reasons[id]!=0 && rulings[id]==0,"Assigned auditor only");
        require(ruling!=0,"Ruling required"); rulings[id]=ruling;
        escrow.applyResolution(id,providerAmount); emit DisputeResolved(id,msg.sender,providerAmount,ruling);
    }
}
