// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;
import "./RoleRegistry.sol";

contract PaymentEscrow {
    enum State { Draft, Funded, Submitted, Disputed, Paid, Refunded, Cancelled, Resolved }
    struct Agreement {
        address customer; address provider; address auditor;
        uint256 amount; uint64 deadline; uint64 submittedAt;
        State state; bytes32 termsHash; bytes32 workHash;
    }
    RoleRegistry public immutable registry;
    address public board;
    uint256 public nextId;
    uint256 public constant REVIEW_PERIOD = 3 days;
    mapping(uint256 => Agreement) private agreements;
    mapping(address => uint256) public credits;
    uint256 public lockedTotal;
    uint256 public creditTotal;
    bool private entered;
    event Activity(uint256 indexed id, address indexed actor, uint8 action, uint256 amount, bytes32 digest);
    event CreditWithdrawn(address indexed account, uint256 amount);
    event BoardBound(address indexed board);
    modifier valid(uint256 id) { require(id < nextId, "Unknown agreement"); _; }
    constructor(address access) { require(access.code.length > 0, "Registry required"); registry = RoleRegistry(access); }
    function bindBoard(address target) external {
        require(msg.sender == registry.admin() && board == address(0), "Binding forbidden");
        require(target.code.length > 0, "Board required"); board = target; emit BoardBound(target);
    }
    function getAgreement(uint256 id) external view valid(id) returns(Agreement memory) { return agreements[id]; }
    function createAgreement(address provider, address auditor, uint256 amount, uint64 deadline, bytes32 terms) external {
        require(board != address(0), "Board not bound");
        require(registry.hasRole(msg.sender, 2) && registry.hasRole(provider, 4), "Role required");
        require(registry.hasRole(auditor, 8), "Auditor required");
        require(provider != msg.sender && auditor != msg.sender && auditor != provider, "Conflict of interest");
        require(amount > 0 && deadline > block.timestamp && deadline <= block.timestamp + 365 days && terms != 0, "Invalid terms");
        uint256 id = nextId++;
        agreements[id] = Agreement(msg.sender, provider, auditor, amount, deadline, 0, State.Draft, terms, 0);
        emit Activity(id, msg.sender, 0, amount, terms);
    }
    function amendAgreement(uint256 id, uint256 amount, uint64 deadline, bytes32 terms) external valid(id) {
        Agreement storage a = agreements[id];
        require(msg.sender == a.customer && a.state == State.Draft, "Draft owner only");
        require(amount > 0 && deadline > block.timestamp && deadline <= block.timestamp + 365 days && terms != 0, "Invalid terms");
        a.amount=amount; a.deadline=deadline; a.termsHash=terms;
        emit Activity(id,msg.sender,1,amount,terms);
    }
    function cancelAgreement(uint256 id) external valid(id) {
        Agreement storage a=agreements[id]; require(msg.sender==a.customer && a.state==State.Draft,"Draft owner only");
        a.state=State.Cancelled; emit Activity(id,msg.sender,2,0,0);
    }
    function fundAgreement(uint256 id) external payable valid(id) {
        Agreement storage a=agreements[id];
        require(msg.sender==a.customer && a.state==State.Draft,"Draft owner only");
        require(block.timestamp < a.deadline && msg.value==a.amount,"Incorrect funding");
        a.state=State.Funded; lockedTotal+=msg.value; emit Activity(id,msg.sender,3,msg.value,0);
    }
    function submitWork(uint256 id, bytes32 digest) external valid(id) {
        Agreement storage a=agreements[id];
        require(msg.sender==a.provider && a.state==State.Funded,"Provider only");
        require(block.timestamp <= a.deadline && digest!=0,"Invalid delivery");
        a.workHash=digest; a.submittedAt=uint64(block.timestamp); a.state=State.Submitted;
        emit Activity(id,msg.sender,4,0,digest);
    }
    function requestRevision(uint256 id) external valid(id) {
        Agreement storage a=agreements[id];
        require(msg.sender==a.customer && a.state==State.Submitted,"Customer review only");
        require(block.timestamp < a.submittedAt+REVIEW_PERIOD && block.timestamp < a.deadline,"Review expired");
        a.state=State.Funded; emit Activity(id,msg.sender,5,0,0);
    }
    function approveWork(uint256 id) external valid(id) {
        Agreement storage a=agreements[id]; require(msg.sender==a.customer && a.state==State.Submitted,"Customer review only");
        settle(id,a.amount,State.Paid,6);
    }
    function claimAfterReview(uint256 id) external valid(id) {
        Agreement storage a=agreements[id];
        require(msg.sender==a.provider && a.state==State.Submitted,"Provider review only");
        require(block.timestamp >= a.submittedAt+REVIEW_PERIOD,"Review active"); settle(id,a.amount,State.Paid,7);
    }
    function refundExpired(uint256 id) external valid(id) {
        Agreement storage a=agreements[id]; require(msg.sender==a.customer && a.state==State.Funded,"Funded customer only");
        require(block.timestamp>a.deadline,"Delivery active"); settle(id,0,State.Refunded,8);
    }
    function flagDispute(uint256 id, address actor) external valid(id) {
        require(msg.sender==board,"Board only"); Agreement storage a=agreements[id];
        require(actor==a.customer || actor==a.provider,"Party only");
        require(a.state==State.Funded || a.state==State.Submitted,"Not disputable");
        if(a.state==State.Submitted) require(block.timestamp<a.submittedAt+REVIEW_PERIOD,"Review expired");
        a.state=State.Disputed; emit Activity(id,actor,9,0,0);
    }
    function applyResolution(uint256 id, uint256 providerAmount) external valid(id) {
        require(msg.sender==board && agreements[id].state==State.Disputed,"Board dispute only");
        require(providerAmount<=agreements[id].amount,"Invalid allocation"); settle(id,providerAmount,State.Resolved,10);
    }
    function settle(uint256 id,uint256 providerAmount,State status,uint8 action) private {
        Agreement storage a=agreements[id]; a.state=status; lockedTotal-=a.amount; creditTotal+=a.amount;
        credits[a.provider]+=providerAmount; credits[a.customer]+=a.amount-providerAmount;
        emit Activity(id,msg.sender,action,providerAmount,0);
    }
    function withdrawCredit() external {
        require(!entered,"Reentrancy"); uint256 amount=credits[msg.sender]; require(amount>0,"No credit");
        entered=true; credits[msg.sender]=0; creditTotal-=amount;
        (bool ok,)=msg.sender.call{value:amount}(""); require(ok,"Transfer failed");
        entered=false; emit CreditWithdrawn(msg.sender,amount);
    }
}
