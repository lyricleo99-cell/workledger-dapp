// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;

contract RoleRegistry {
    address public immutable admin;
    mapping(address => uint8) public roles;
    event RoleChanged(address indexed account, uint8 roles);
    constructor() { admin = msg.sender; roles[msg.sender] = 1; }
    function hasRole(address who, uint8 role) external view returns(bool) { return roles[who] & role != 0; }
    // Customer (2) and provider (4) are self-service; auditor (8) is governed.
    function enroll(uint8 role) external {
        require(role == 2 || role == 4, "Invalid role");
        require(roles[msg.sender] & role == 0, "Already enrolled");
        roles[msg.sender] |= role; emit RoleChanged(msg.sender, roles[msg.sender]);
    }
    function setAuditor(address who, bool enabled) external {
        require(msg.sender == admin, "Admin only");
        require(who != address(0), "Zero address");
        require((roles[who] & 8 != 0) != enabled, "Unchanged");
        if(enabled) roles[who] |= 8; else roles[who] &= 247;
        emit RoleChanged(who, roles[who]);
    }
}
