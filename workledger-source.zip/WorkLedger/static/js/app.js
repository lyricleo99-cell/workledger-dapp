/* global ethers */
'use strict';
const $=id=>document.getElementById(id),S={config:null,account:null,roles:0,items:[],provider:null,busy:false,generation:0};
const node=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
const short=a=>a?a.slice(0,6)+'…'+a.slice(-4):'—';
const eth=v=>ethers.formatEther(v||'0');
const digest=v=>ethers.keccak256(ethers.toUtf8Bytes(v.trim()));
function alertMessage(text,error=false){$('notice').textContent=text;$('notice').className=error?'error':'';$('notice').hidden=false;}
function errorText(e){return e.code===4001||e.code==='ACTION_REJECTED'?'Wallet request cancelled.':e.reason||e.shortMessage||e.message||'Request failed.';}
async function api(path,data){const r=await fetch(path,data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json','X-Requested-With':'WorkLedger'},body:JSON.stringify(data)});const j=await r.json();if(!r.ok)throw Error(j.error||'Request failed');return j;}
function access(){
 const on=Boolean(S.account)&&!S.busy;
 $('create').disabled=!(on&&(S.roles&2));$('customer').disabled=!on||Boolean(S.roles&2);$('provider').disabled=!on||Boolean(S.roles&4);
 $('withdraw').disabled=!on||BigInt(S.credit||0)===0n;$('sync').disabled=!on;$('audit').disabled=!(on&&(S.roles&9));$('admin-tools').hidden=!(S.roles&1);
 $('logout').hidden=!S.account;$('connect').disabled=S.busy;$('connect').textContent=S.account?short(S.account):'Connect & sign in';
 $('who').textContent=S.account||'Wallet not connected';$('roles').textContent=S.account?[[1,'Administrator'],[2,'Customer'],[4,'Provider'],[8,'Auditor']].filter(([n])=>S.roles&n).map(x=>x[1]).join(' · ')||'Choose a business role':'Sign in to your workspace';
 $('credit').textContent=S.account?eth(S.credit):'—';
}
const specs={
 enroll:{contract:'RoleRegistry',method:'enroll'},setAuditor:{contract:'RoleRegistry',method:'setAuditor'},
 create:{contract:'PaymentEscrow',method:'createAgreement',fields:[['provider','Provider wallet','text'],['auditor','Independent auditor wallet','text'],['amount','Amount (test ETH)','text'],['deadline','Delivery deadline','datetime-local'],['terms','Public scope description (hash stored on chain)','textarea']]},
 amend:{contract:'PaymentEscrow',method:'amendAgreement',fields:[['amount','New amount (test ETH)','text'],['deadline','New deadline','datetime-local'],['terms','Revised scope','textarea']]},
 cancel:{contract:'PaymentEscrow',method:'cancelAgreement'},fund:{contract:'PaymentEscrow',method:'fundAgreement'},
 submit:{contract:'PaymentEscrow',method:'submitWork',fields:[['evidence','Delivery evidence or reference (hash stored on chain)','textarea']]},
 revision:{contract:'PaymentEscrow',method:'requestRevision'},approve:{contract:'PaymentEscrow',method:'approveWork'},
 claim:{contract:'PaymentEscrow',method:'claimAfterReview'},refund:{contract:'PaymentEscrow',method:'refundExpired'},
 dispute:{contract:'DisputeBoard',method:'openDispute',fields:[['reason','Dispute reason (hash stored on chain)','textarea']]},
 resolve:{contract:'DisputeBoard',method:'resolveDispute',fields:[['amount','Amount allocated to provider (test ETH)','text'],['ruling','Ruling explanation (hash stored on chain)','textarea']]},
 withdraw:{contract:'PaymentEscrow',method:'withdrawCredit'}
};
const labels={create:'Create agreement',amend:'Amend draft',cancel:'Cancel draft',fund:'Fund escrow',submit:'Submit work',revision:'Request revision',approve:'Approve payment',claim:'Claim after review',refund:'Refund expired delivery',dispute:'Open dispute',resolve:'Resolve dispute',withdraw:'Withdraw credit',enroll:'Enroll business role',setAuditor:'Change auditor access'};
function openAction(key,a=null,args=null){
 S.action={key,a,args};S.prepared=null;$('action-fields').replaceChildren();$('estimate-box').hidden=true;$('action-error').textContent='';$('action-title').textContent=labels[key];$('estimate').disabled=false;
 for(const [id,label,type] of specs[key].fields||[]){const l=node('label',label),input=node(type==='textarea'?'textarea':'input');input.id='field-'+id;input.required=true;if(type!=='textarea')input.type=type;else input.maxLength=2000;l.append(input);$('action-fields').append(l);}
 $('action-help').textContent=key==='fund'?'The exact agreement amount is locked until approval, timeout refund or dispute resolution.':key==='resolve'?'The remainder is credited to the customer. Both parties withdraw separately.':'Review the gas estimate before requesting wallet confirmation. No funds move during estimation.';
 $('action-dialog').showModal();
}
function values(){const v={};for(const [id] of specs[S.action.key].fields||[])v[id]=$('field-'+id).value.trim();return v;}
function amount(v,zero=false){if(!/^(0|[1-9]\d*)(\.\d{1,18})?$/.test(v))throw Error('Enter a decimal ETH amount with at most 18 decimal places.');const n=ethers.parseEther(v);if(!zero&&n===0n)throw Error('Amount must be positive.');return n;}
function date(v){const n=Math.floor(new Date(v).getTime()/1000);if(!Number.isFinite(n)||n<=S.timestamp||n>S.timestamp+31536000)throw Error('Deadline must be in the next 365 days.');return n;}
function makeArgs(){const {key,a,args}=S.action,v=values();if(args)return args;
 switch(key){case 'create':if(!ethers.isAddress(v.provider)||!ethers.isAddress(v.auditor))throw Error('Enter valid wallet addresses.');return [v.provider,v.auditor,amount(v.amount),date(v.deadline),digest(v.terms)];
 case 'amend':return [a.id,amount(v.amount),date(v.deadline),digest(v.terms)];case 'submit':return [a.id,digest(v.evidence)];case 'dispute':return [a.id,digest(v.reason)];case 'resolve':return [a.id,amount(v.amount,true),digest(v.ruling)];case 'withdraw':return [];default:return [a.id];}
}
function actions(a){if(!S.account)return [];const out=[],who=S.account.toLowerCase(),customer=a.customer.toLowerCase()===who,provider=a.provider.toLowerCase()===who,auditor=a.auditor.toLowerCase()===who;
 if(customer&&a.state==='Draft')out.push('amend','cancel',...(S.timestamp<a.deadline?['fund']:[]));
 if(provider&&a.state==='Funded'&&S.timestamp<=a.deadline)out.push('submit');
 if(customer&&a.state==='Submitted')out.push('approve',...(S.timestamp<a.deadline&&S.timestamp<a.submittedAt+259200?['revision']:[]));
 if(provider&&a.state==='Submitted'&&S.timestamp>=a.submittedAt+259200)out.push('claim');
 if(customer&&a.state==='Funded'&&S.timestamp>a.deadline)out.push('refund');
 if((customer||provider)&&(a.state==='Funded'||a.state==='Submitted'&&S.timestamp<a.submittedAt+259200))out.push('dispute');
 if(auditor&&a.state==='Disputed')out.push('resolve');return out;
}
function render(){
 $('cards').replaceChildren();const counts={};
 for(const a of S.items){counts[a.state]=(counts[a.state]||0)+1;const card=node('article',undefined,'card');card.dataset.id=a.id;card.append(node('span',a.state,'badge'),node('h3','Agreement #'+a.id),node('div',eth(a.amountWei)+' ETH','amount'));const dl=node('dl');
 for(const [k,v] of [['Customer',short(a.customer)],['Provider',short(a.provider)],['Auditor',short(a.auditor)],['Deadline',new Date(a.deadline*1000).toLocaleString()],['Terms hash',short(a.termsHash)]])dl.append(node('dt',k),node('dd',v));card.append(dl);
 const allowed=actions(a);if(allowed.length){const select=node('select');select.setAttribute('aria-label','Action for agreement '+a.id);for(const key of allowed){const o=node('option',labels[key]);o.value=key;select.append(o);}const btn=node('button','Review action','primary');btn.disabled=S.busy;btn.onclick=()=>openAction(select.value,a);card.append(select,btn);}
 if(S.account&&([a.customer,a.provider,a.auditor].some(x=>x.toLowerCase()===S.account.toLowerCase())||(S.roles&1))){const b=node('button','Notes');b.onclick=()=>openNotes(a.id);card.append(b);} $('cards').append(card);}
 if(!S.items.length)$('cards').append(node('div','No agreements yet. A customer can create the first project agreement.','empty'));
 $('chart').replaceChildren();for(const [name,count] of Object.entries(counts)){const row=node('div',undefined,'bar-row'),p=node('progress');p.max=S.items.length;p.value=count;row.append(node('span',name),p,node('span',String(count)));$('chart').append(row);}if(!S.items.length)$('chart').append(node('p','No agreement data.','muted'));
 access();
}
async function refresh(append=false){const gen=S.generation;const data=await api('/api/agreements?offset='+(append?S.next||0:0));if(gen!==S.generation)return;S.items=append?[...S.items,...data.items]:data.items;S.next=data.nextOffset;S.timestamp=data.timestamp;$('total').textContent=data.total;$('locked').textContent=eth(data.lockedWei);$('more').hidden=S.next===null;
 if(S.account){const me=await api('/api/me');if(gen!==S.generation)return;S.roles=me.roles;S.credit=me.creditWei;}render();await loadEvents();}
async function loadEvents(append=false){const data=await api('/api/events?offset='+(append?S.eventOffset||0:0));if(!append)$('events').replaceChildren();for(const e of data.items){const tr=node('tr'),td=node('td');if(S.config.chainId===11155111){const link=node('a',short(e.tx));link.href='https://sepolia.etherscan.io/tx/'+e.tx;link.target='_blank';link.rel='noopener';td.append(link);}else td.textContent=short(e.tx);tr.append(node('td',e.name),node('td',String(e.block)),node('td',e.data),td);$('events').append(tr);}S.eventOffset=data.nextOffset;$('more-events').hidden=S.eventOffset===null;}
async function openNotes(id){S.noteId=id;$('note-status').textContent='';$('note-body').value='';$('notes-dialog').showModal();try{const d=await api('/api/agreements/'+id+'/notes');$('notes-list').replaceChildren();for(const n of d.items)$('notes-list').append(node('div',short(n.author)+' · '+new Date(n.created*1000).toLocaleString()+'\n'+n.body,'note'));}catch(e){$('note-status').textContent=errorText(e);}}
$('note-form').onsubmit=async e=>{e.preventDefault();try{await api('/api/agreements/'+S.noteId+'/notes',{body:$('note-body').value});await openNotes(S.noteId);$('note-status').textContent='Note saved.';}catch(err){$('note-status').textContent=errorText(err);}};
$('close-notes').onclick=()=>$('notes-dialog').close();$('close-action').onclick=()=>$('action-dialog').close();
$('action-form').onsubmit=async e=>{e.preventDefault();$('action-error').textContent='';$('estimate-box').hidden=true;try{
 if(!S.account||!S.provider)throw Error('Sign in first.');if((await S.provider.getNetwork()).chainId!==BigInt(S.config.chainId))throw Error('Switch to the configured network.');
 const signer=await S.provider.getSigner();if((await signer.getAddress()).toLowerCase()!==S.account.toLowerCase())throw Error('Wallet changed. Sign in again.');const spec=specs[S.action.key],args=makeArgs(),overrides=S.action.key==='fund'?{value:BigInt(S.action.a.amountWei)}:{};
 const con=new ethers.Contract(S.config.addresses[spec.contract],S.config.abi[spec.contract],signer),gas=await con[spec.method].estimateGas(...args,overrides),fee=await S.provider.getFeeData();
 S.prepared={con,spec,args,overrides,account:S.account};$('estimate-text').textContent='Estimated gas: '+gas.toString()+' units. Estimated maximum network fee: '+eth(gas*(fee.maxFeePerGas||fee.gasPrice||0n))+' ETH. Your wallet shows the final fee.';$('estimate-box').hidden=false;
 }catch(err){$('action-error').textContent=errorText(err);}};
$('action-form').oninput=()=>{S.prepared=null;$('estimate-box').hidden=true;};
$('confirm').onclick=async()=>{if(!S.prepared||S.busy)return;S.busy=true;access();$('confirm').disabled=true;try{const p=S.prepared;if((await S.provider.getNetwork()).chainId!==BigInt(S.config.chainId)||(await S.provider.getSigner()).address.toLowerCase()!==p.account.toLowerCase())throw Error('Wallet changed. Sign in again.');alertMessage('Waiting for wallet confirmation.');const tx=await p.con[p.spec.method](...p.args,p.overrides);localStorage.setItem('workledger-pending',JSON.stringify({hash:tx.hash,chain:S.config.chainId}));alertMessage('Transaction submitted: '+tx.hash);$('action-dialog').close();const receipt=await tx.wait(1,120000);if(!receipt||receipt.status!==1)throw Error('Transaction reverted.');localStorage.removeItem('workledger-pending');alertMessage('Transaction confirmed in block '+receipt.blockNumber+'. One block inclusion is not finality.');await refresh();}catch(e){alertMessage(errorText(e),true);}finally{S.busy=false;S.prepared=null;$('confirm').disabled=false;render();}};
$('connect').onclick=async()=>{try{if(!window.ethereum)throw Error('Install MetaMask in this browser to sign in.');if(!S.config.configured)throw Error('Blockchain connection is not configured.');S.provider=new ethers.BrowserProvider(window.ethereum);await window.ethereum.request({method:'eth_requestAccounts'});if((await S.provider.getNetwork()).chainId!==BigInt(S.config.chainId)){await window.ethereum.request({method:'wallet_switchEthereumChain',params:[{chainId:ethers.toBeHex(S.config.chainId)}]});S.provider=new ethers.BrowserProvider(window.ethereum);}
 const signer=await S.provider.getSigner(),account=await signer.getAddress(),ch=await api('/api/auth/challenge',{address:account});const signature=await signer.signMessage(ch.message);await api('/api/auth/verify',{id:ch.id,signature});S.account=account;S.generation++;await refresh();alertMessage('Signed in securely. Signing in does not move funds.');const pending=JSON.parse(localStorage.getItem('workledger-pending')||'null');if(pending&&pending.chain===S.config.chainId){const receipt=await S.provider.getTransactionReceipt(pending.hash);alertMessage(receipt?'Previous transaction '+(receipt.status===1?'confirmed.':'reverted.'):'Previous transaction still awaiting confirmation: '+pending.hash);if(receipt)localStorage.removeItem('workledger-pending');}
 }catch(e){alertMessage(errorText(e),true);}};
async function logout(){await api('/api/auth/logout',{});S.account=null;S.roles=0;S.credit=0;S.generation++;S.prepared=null;$('action-dialog').close();$('notes-dialog').close();$('notes-list').replaceChildren();$('audit-log').textContent='Audit access requires a signed-in auditor or administrator.';render();}
$('logout').onclick=()=>logout().catch(e=>alertMessage(errorText(e),true));
$('create').onclick=()=>openAction('create');$('customer').onclick=()=>openAction('enroll',null,[2]);$('provider').onclick=()=>openAction('enroll',null,[4]);$('withdraw').onclick=()=>openAction('withdraw');
$('auditor-form').onsubmit=e=>{e.preventDefault();const a=$('auditor-address').value.trim();if(!ethers.isAddress(a)){alertMessage('Enter a valid auditor address.',true);return;}openAction('setAuditor',null,[a,$('auditor-enabled').value==='true']);};
$('more').onclick=()=>refresh(true).catch(e=>alertMessage(errorText(e),true));$('more-events').onclick=()=>loadEvents(true).catch(e=>alertMessage(errorText(e),true));
$('sync').onclick=async()=>{try{$('sync').disabled=true;const r=await api('/api/events/sync',{});alertMessage('Indexed '+r.events+' events through block '+r.toBlock+(r.hasMore?'. More blocks available; sync again.':'.'));await loadEvents();}catch(e){alertMessage(errorText(e),true);}finally{access();}};
$('audit').onclick=async()=>{try{const r=await api('/api/audit');$('audit-log').replaceChildren();for(const a of r.items)$('audit-log').append(node('p',new Date(a.created*1000).toLocaleString()+' · '+short(a.actor)+' · '+a.action));}catch(e){alertMessage(errorText(e),true);}};
(async()=>{try{S.config=await api('/api/config');$('network').textContent=S.config.chainId===11155111?'Sepolia testnet':'Local test chain';if(S.config.configured){await api('/api/status');await refresh();}else alertMessage('Contracts are not connected to this deployment.',true);if(window.ethereum){window.ethereum.on('accountsChanged',()=>logout().catch(()=>{}));window.ethereum.on('chainChanged',()=>logout().catch(()=>{}));}access();}catch(e){alertMessage(errorText(e),true);}})();
