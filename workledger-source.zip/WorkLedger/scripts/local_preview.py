"""Local isolated demonstration, never a public network deployment."""
import sys,json,os
from pathlib import Path
from web3 import Web3
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from conftest import deploy
from app import create_app
w=Web3(Web3.HTTPProvider('http://127.0.0.1:19545'));assert w.eth.chain_id==1337
contracts=deploy(w);a=w.eth.accounts;e=contracts['PaymentEscrow'];b=contracts['DisputeBoard'];r=contracts['RoleRegistry'];measure={}
def tx(name,call,sender,value=0):
 receipt=w.eth.wait_for_transaction_receipt(call.transact({'from':sender,'value':value}));measure[name]={'gasUsed':receipt.gasUsed,'transactionHash':Web3.to_hex(receipt.transactionHash),'status':receipt.status};return receipt
def new(amount=10**15,delay=86400):
 i=e.functions.nextId().call();tx('createAgreement',e.functions.createAgreement(a[2],a[3],amount,w.eth.get_block('latest').timestamp+delay,Web3.keccak(text='Website delivery scope')),a[1]);return i
tx('enroll',r.functions.enroll(2),a[4]);tx('setAuditor',r.functions.setAuditor(a[5],True),a[0])
i=new();tx('amendAgreement',e.functions.amendAgreement(i,10**15,w.eth.get_block('latest').timestamp+86400,Web3.keccak(text='Revised scope')),a[1]);tx('cancelAgreement',e.functions.cancelAgreement(i),a[1])
i=new();tx('fundAgreement',e.functions.fundAgreement(i),a[1],10**15);tx('submitWork',e.functions.submitWork(i,Web3.keccak(text='delivery v1')),a[2]);tx('requestRevision',e.functions.requestRevision(i),a[1]);tx('submitWork',e.functions.submitWork(i,Web3.keccak(text='delivery v2')),a[2]);tx('approveWork',e.functions.approveWork(i),a[1]);tx('withdrawCredit',e.functions.withdrawCredit(),a[2])
i=new();tx('fundAgreement',e.functions.fundAgreement(i),a[1],10**15);tx('openDispute',b.functions.openDispute(i,Web3.keccak(text='Incomplete scope')),a[1]);tx('resolveDispute',b.functions.resolveDispute(i,4*10**14,Web3.keccak(text='40 percent delivered')),a[3])
i=new(delay=60);tx('fundAgreement',e.functions.fundAgreement(i),a[1],10**15);w.provider.make_request('evm_increaseTime',[61]);w.provider.make_request('evm_mine',[]);tx('refundExpired',e.functions.refundExpired(i),a[1])
i=new();tx('fundAgreement',e.functions.fundAgreement(i),a[1],10**15);tx('submitWork',e.functions.submitWork(i,Web3.keccak(text='Delivered')),a[2]);w.provider.make_request('evm_increaseTime',[259201]);w.provider.make_request('evm_mine',[]);tx('claimAfterReview',e.functions.claimAfterReview(i),a[2])
for amount in [2*10**15,3*10**15]:
 i=new(amount);tx('fundAgreement',e.functions.fundAgreement(i),a[1],amount)
i=new();tx('fundAgreement',e.functions.fundAgreement(i),a[1],10**15);tx('openDispute',b.functions.openDispute(i,Web3.keccak(text='Review needed')),a[2])
(ROOT/'tests/gas-results.json').write_text(json.dumps({'network':'local Ganache 1337','transactionTypes':measure},indent=2))
config={'CHAIN_ID':1337,'PUBLIC_ORIGIN':'http://127.0.0.1:5100','SECRET_KEY':'local-example-secret-not-for-public-use','DATABASE_URL':'sqlite:///'+str(ROOT/'local-demo.db').replace(chr(92),'/'),'ADDRESSES':{k:v.address for k,v in contracts.items()},'ENABLE_DEPLOY_UI':True}
app=create_app(config,w);app.run(host='127.0.0.1',port=5100,threaded=True)
