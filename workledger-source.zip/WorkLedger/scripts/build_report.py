from pathlib import Path
import json,re
from html import escape
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Image
from reportlab.graphics.shapes import Drawing,Rect,String,Line,Polygon
from reportlab.graphics import renderSVG
ROOT=Path(__file__).resolve().parents[1];DOCS=ROOT/'docs';W=A4[0]-112
body=ParagraphStyle('body',fontName='Times-Roman',fontSize=10.6,leading=14.6,spaceAfter=10)
h2=ParagraphStyle('h2',fontName='Times-Bold',fontSize=17,leading=21,spaceAfter=15)
h3=ParagraphStyle('h3',fontName='Times-Bold',fontSize=12,leading=16,spaceBefore=8,spaceAfter=8)
small=ParagraphStyle('small',fontName='Times-Italic',fontSize=9,leading=12,spaceAfter=10)
def diagram(name):
 specs={
 'architecture':(['Browser UI','MetaMask wallet','Ethereum contracts','Flask REST API','SQL database','RPC provider'],[(0,1),(1,2),(0,3),(3,4),(3,5),(5,2)],3),
 'contracts':(['RoleRegistry','PaymentEscrow','DisputeBoard'],[(1,0),(2,1),(2,0)],3),
 'flow':(['Draft','Funded','Submitted','Paid / credit','Cancelled','Refunded','Disputed','Resolved / credit'],[(0,1),(1,2),(2,3),(0,4),(1,5),(2,6),(6,7)],4),
 'data':(['Challenges / sessions','Private notes','Audit log','Index cursor','Chain events','On-chain agreement'],[(0,2),(1,5),(3,4),(4,5)],3),
 'ui':(['Connect + sign','Role workspace','Choose action','Refreshed card','Receipt status','Estimate + confirm'],[(0,1),(1,2),(2,5),(5,4),(4,3)],3)}
 labels,edges,cols=specs[name];d=Drawing(W,150 if len(labels)>cols else 90);bw=(W-18*(cols-1))/cols;bh=36;positions=[]
 for idx,label in enumerate(labels):
  ri,i=divmod(idx,cols);x=i*(bw+18);y=d.height-51-ri*72;positions.append((x,y))
  d.add(Rect(x,y,bw,bh,fillColor=colors.HexColor('#eef3f3'),strokeColor=colors.HexColor('#52696c'),strokeWidth=.6));d.add(String(x+bw/2,y+15,label,fontName='Helvetica',fontSize=8.2,textAnchor='middle'))
 for src,dst in edges:
  x,y=positions[src];xx,yy=positions[dst]
  if y==yy and abs(src-dst)==1:
   start=(x+bw if xx>x else x,y+bh/2);end=(xx if xx>x else xx+bw,yy+bh/2)
   pts=[start,end]
  elif x==xx:
   start=(x+bw/2,y if yy<y else y+bh);end=(xx+bw/2,yy+bh if yy<y else yy);pts=[start,end]
  else:
   start=(x+bw/2,y+bh);end=(xx+bw/2,yy+bh);via=max(y,yy)+bh+8;pts=[start,(start[0],via),(end[0],via),end]
  for p1,p2 in zip(pts,pts[1:]):d.add(Line(*p1,*p2,strokeWidth=.6))
  ex,ey=pts[-1];px,py=pts[-2];dx,dy=ex-px,ey-py
  if abs(dx)>abs(dy):dx=1 if dx>0 else -1;triangle=[ex,ey,ex-4*dx,ey+2,ex-4*dx,ey-2]
  else:dy=1 if dy>0 else -1;triangle=[ex,ey,ex+2,ey-4*dy,ex-2,ey-4*dy]
  d.add(Polygon(triangle,fillColor=colors.black))
 renderSVG.drawToFile(d,str(DOCS/(name+'.svg')));return d

def inline(t):
 t=escape(t);t=re.sub(r'`([^`]+)`',r'<font name="Courier" size="9">\1</font>',t);return t

def footer(c,doc):
 if doc.page==1:
  c.setFont('Times-Roman',11);c.drawCentredString(A4[0]/2,A4[1]-85,'SC6113-DEVELOPMENT OF DECENTRALIZED APPLICATIONS')
  c.setFont('Times-Bold',23);c.drawCentredString(A4[0]/2,A4[1]-170,'WorkLedger')
  c.setFont('Times-Bold',16);c.drawCentredString(A4[0]/2,A4[1]-201,'Enterprise Escrow DApp')
  c.setFont('Times-Roman',12);c.drawCentredString(A4[0]/2,A4[1]-260,'Group Project Report')
  c.setFont('Times-Roman',14);c.drawCentredString(A4[0]/2,A4[1]-325,'Liu Yanrong');return
 c.setFont('Times-Roman',10);c.drawCentredString(A4[0]/2,30,str(doc.page-1))
def build():
 parts=(DOCS/'Technical_Report.md').read_text(encoding='utf-8').split('<!-- PAGE -->');story=[Spacer(1,1)]
 for part in parts[1:]:
  story.append(PageBreak())
  for line in part.strip().splitlines():
   if not line.strip():continue
   if line.startswith('[DIAGRAM '):story.extend([diagram(line[9:-1]),Spacer(1,8)])
   elif line.startswith('[SCREENSHOT '):
    from PIL import Image as PI
    import io
    im=PI.open(ROOT/'screenshots'/line[12:-1]);im=im.crop((226,90,1440,930));buf=io.BytesIO();im.save(buf,format='PNG');buf.seek(0);story.append(Image(buf,width=310,height=310*im.height/im.width));story.append(Spacer(1,7))
   elif line=='[GAS]':
    gas=json.loads((ROOT/'tests/gas-results.json').read_text())['transactionTypes']
    text='; '.join(f"{k}: {v['gasUsed']:,}" for k,v in gas.items())+'.'
    story.append(Paragraph('<b>Gas units by operation.</b> '+text,body))
   elif line.startswith('## '):story.append(Paragraph(inline(line[3:]),h2))
   elif line.startswith('### '):story.append(Paragraph(inline(line[4:]),h3))
   else:story.append(Paragraph(inline(line),small if line.startswith(('Figure ','[1]','[2]','[3]','[4]','[5]')) else body))
 SimpleDocTemplate(str(DOCS/'WorkLedger_Technical_Report.pdf'),pagesize=A4,leftMargin=56,rightMargin=56,topMargin=52,bottomMargin=48,author='Liu Yanrong',title='WorkLedger Enterprise Escrow DApp').build(story,onFirstPage=footer,onLaterPages=footer)
if __name__=='__main__':build()
