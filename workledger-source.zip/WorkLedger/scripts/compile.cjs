const fs=require('fs'),path=require('path'),solc=require('solc');
const root=path.resolve(__dirname,'..'),sources={};
for(const name of fs.readdirSync(path.join(root,'contracts')).filter(n=>n.endsWith('.sol')))sources[name]={content:fs.readFileSync(path.join(root,'contracts',name),'utf8')};
const input={language:'Solidity',sources,settings:{optimizer:{enabled:true,runs:200},evmVersion:'paris',outputSelection:{'*':{'*':['abi','evm.bytecode.object','evm.deployedBytecode.object']}}}};
const out=JSON.parse(solc.compile(JSON.stringify(input)));for(const e of out.errors||[])console.log(e.formattedMessage);if((out.errors||[]).some(e=>e.severity==='error'))process.exit(1);
for(const [file,contracts] of Object.entries(out.contracts))for(const [name,c] of Object.entries(contracts)){fs.writeFileSync(path.join(root,'abi',name+'.json'),JSON.stringify(c.abi,null,2));fs.writeFileSync(path.join(root,'artifacts',name+'.json'),JSON.stringify({contractName:name,compiler:solc.version(),abi:c.abi,bytecode:'0x'+c.evm.bytecode.object,deployedBytecode:'0x'+c.evm.deployedBytecode.object},null,2));}
console.log('Compiled three interacting WorkLedger contracts.');

const receiverInput={...input,sources:{"Receiver.sol":{content:fs.readFileSync(path.join(root,"tests/Receiver.sol"),"utf8")}}};
const receiverOutput=JSON.parse(solc.compile(JSON.stringify(receiverInput)));
if((receiverOutput.errors||[]).some(e=>e.severity==="error"))throw new Error(JSON.stringify(receiverOutput.errors));
const receiver=receiverOutput.contracts["Receiver.sol"].Receiver;
fs.writeFileSync(path.join(root,"tests/Receiver.json"),JSON.stringify({abi:receiver.abi,bytecode:"0x"+receiver.evm.bytecode.object},null,2));
