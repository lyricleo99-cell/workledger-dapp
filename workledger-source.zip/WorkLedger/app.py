"""WorkLedger REST service. Signing and custody stay outside the web server."""
import hashlib
import json
import os
import secrets
import time
from datetime import datetime, timezone, timedelta
from functools import wraps
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv
from flask import Flask, jsonify, request, session, render_template
from sqlalchemy import create_engine, MetaData, Table, Column, String, Integer, Text, select, update, delete, func
from sqlalchemy.exc import SQLAlchemyError
from eth_account import Account
from eth_account.messages import encode_defunct
from web3 import Web3

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / '.env')
NAMES = ['RoleRegistry', 'PaymentEscrow', 'DisputeBoard']
ARTIFACTS = {n: json.loads((ROOT / 'artifacts' / (n+'.json')).read_text()) for n in NAMES}
STATES = ['Draft','Funded','Submitted','Disputed','Paid','Refunded','Cancelled','Resolved']

def create_app(overrides=None, client=None):
    app=Flask(__name__)
    app.config.update(SECRET_KEY=os.getenv('SECRET_KEY') or secrets.token_hex(32),
        DATABASE_URL=os.getenv('DATABASE_URL', 'sqlite:///'+str(ROOT/'workledger.db').replace('\\','/')),
        PUBLIC_ORIGIN=os.getenv('PUBLIC_ORIGIN','http://127.0.0.1:5100').rstrip('/'),
        RPC_URL=os.getenv('RPC_URL',''), CHAIN_ID=int(os.getenv('CHAIN_ID','11155111')),
        DEPLOYMENT_BLOCK=int(os.getenv('DEPLOYMENT_BLOCK','0')),
        ADDRESSES={n:os.getenv(n.upper()+'_ADDRESS','') for n in NAMES},
        ENABLE_DEPLOY_UI=os.getenv('ENABLE_DEPLOY_UI','false').lower()=='true',
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Strict',
        MAX_CONTENT_LENGTH=16384, PERMANENT_SESSION_LIFETIME=timedelta(hours=1))
    if overrides: app.config.update(overrides)
    app.config['SESSION_COOKIE_SECURE']=app.config['PUBLIC_ORIGIN'].startswith('https://')
    dburl=app.config['DATABASE_URL']
    if dburl.startswith(('postgres://','postgresql://')): dburl='postgresql+psycopg://'+dburl.split('://',1)[1]
    engine=create_engine(dburl,pool_pre_ping=True,connect_args={'check_same_thread':False} if dburl.startswith('sqlite') else {})
    m=MetaData()
    challenges=Table('challenges',m,Column('id',String(64),primary_key=True),Column('address',String(42)),Column('message',Text),Column('expires',Integer),Column('used',Integer))
    sessions=Table('wallet_sessions',m,Column('id',String(64),primary_key=True),Column('address',String(42)),Column('expires',Integer))
    notes=Table('agreement_notes',m,Column('id',Integer,primary_key=True),Column('network',String(100)),Column('agreement',Integer),Column('author',String(42)),Column('body',Text),Column('created',Integer))
    audit=Table('audit_log',m,Column('id',Integer,primary_key=True),Column('actor',String(42)),Column('action',String(60)),Column('created',Integer))
    events=Table('chain_events',m,Column('key',String(200),primary_key=True),Column('network',String(100)),Column('block',Integer),Column('tx',String(66)),Column('name',String(60)),Column('data',Text))
    cursors=Table('event_cursor',m,Column('network',String(100),primary_key=True),Column('block',Integer))
    limits=Table('request_limits',m,Column('key',String(100),primary_key=True),Column('count',Integer))
    m.create_all(engine)
    app.extensions.update(db=engine,tables={'challenges':challenges,'sessions':sessions,'notes':notes,'audit':audit,'events':events})
    w3=client or Web3(Web3.HTTPProvider(app.config['RPC_URL'],request_kwargs={'timeout':10}))

    def contract(name):
        address=app.config['ADDRESSES'][name]
        if not Web3.is_address(address): raise ConnectionError('Configuration unavailable')
        return w3.eth.contract(address=Web3.to_checksum_address(address),abi=ARTIFACTS[name]['abi'])
    def network(): return str(app.config['CHAIN_ID'])+':'+app.config['ADDRESSES']['PaymentEscrow'].lower()
    def address(value):
        if not isinstance(value,str) or not Web3.is_address(value): raise ValueError('A valid wallet address is required.')
        return Web3.to_checksum_address(value)
    def chain():
        if w3.eth.chain_id!=app.config['CHAIN_ID']: raise ConnectionError('Network mismatch')
    def log(c,actor,action):c.execute(audit.insert().values(actor=actor,action=action,created=int(time.time())))
    def actor():
        key=session.get('token','')
        with engine.connect() as c:r=c.execute(select(sessions).where(sessions.c.id==hashlib.sha256(key.encode()).hexdigest(),sessions.c.expires>int(time.time()))).mappings().first()
        if not r: return None
        return r['address']
    def auth(f):
        @wraps(f)
        def wrapped(*a,**kw):
            who=actor()
            if not who:return jsonify(error='Sign in with your wallet.'),401
            return f(who,*a,**kw)
        return wrapped
    def role(who,mask):
        chain();return contract('RoleRegistry').functions.hasRole(who,mask).call()
    def agreement(i):
        if i<0: raise ValueError('Invalid agreement ID.')
        a=contract('PaymentEscrow').functions.getAgreement(i).call()
        return dict(id=i,customer=a[0],provider=a[1],auditor=a[2],amountWei=str(a[3]),deadline=a[4],submittedAt=a[5],state=STATES[a[6]],termsHash=Web3.to_hex(a[7]),workHash=Web3.to_hex(a[8]))
    def can_read(who,a):return who in [a['customer'],a['provider'],a['auditor']] or role(who,1)

    @app.before_request
    def guards():
        if request.method in ['POST','PUT','DELETE']:
            if request.headers.get('X-Requested-With')!='WorkLedger' or not request.is_json:return jsonify(error='JSON application request required.'),403
            if request.headers.get('Origin') not in [None,app.config['PUBLIC_ORIGIN']]:return jsonify(error='Origin rejected.'),403
        if request.path=='/api/auth/challenge':
            now=int(time.time());key=hashlib.sha256((request.remote_addr or '').encode()).hexdigest()+':'+str(now//60)
            with engine.begin() as c:
                r=c.execute(select(limits.c.count).where(limits.c.key==key)).scalar()
                if r is None:c.execute(limits.insert().values(key=key,count=1))
                elif r>=30:return jsonify(error='Too many login requests. Try again later.'),429
                else:c.execute(update(limits).where(limits.c.key==key).values(count=r+1))
                c.execute(delete(challenges).where(challenges.c.expires<now))
                c.execute(delete(sessions).where(sessions.c.expires<now))
                c.execute(delete(limits).where(limits.c.key.not_like('%:'+str(now//60))))
    @app.after_request
    def headers(r):
        r.headers['X-Content-Type-Options']='nosniff';r.headers['X-Frame-Options']='DENY'
        r.headers['Referrer-Policy']='same-origin';r.headers['Cache-Control']='no-store'
        r.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        return r
    @app.errorhandler(ValueError)
    def invalid(e):return jsonify(error=str(e)),400
    @app.errorhandler(Exception)
    def unavailable(e):
        from werkzeug.exceptions import HTTPException
        if isinstance(e,HTTPException):return jsonify(error=e.name),e.code
        app.logger.warning('Request failed: %s',type(e).__name__)
        return jsonify(error='Service unavailable. Refresh and retry.'),503
    @app.get('/')
    def home():return render_template('index.html')
    @app.get('/health')
    def health():
        with engine.connect() as c:c.execute(select(1))
        return jsonify(status='ok')
    @app.get('/api/config')
    def config():return jsonify(chainId=app.config['CHAIN_ID'],addresses=app.config['ADDRESSES'],abi={n:ARTIFACTS[n]['abi'] for n in NAMES},configured=all(Web3.is_address(v) for v in app.config['ADDRESSES'].values()),reviewSeconds=259200)
    @app.get('/api/status')
    def status():
        chain()
        for n in NAMES:
            if not w3.eth.get_code(contract(n).address):raise ConnectionError('Missing contract')
        if contract('PaymentEscrow').functions.board().call()!=contract('DisputeBoard').address:raise ConnectionError('Board mismatch')
        return jsonify(ready=True,block=w3.eth.block_number,chainId=w3.eth.chain_id)
    @app.post('/api/auth/challenge')
    def challenge():
        who=address(request.json.get('address'));now=int(time.time());nonce=secrets.token_hex(16)
        origin=app.config['PUBLIC_ORIGIN'];issued=datetime.fromtimestamp(now,timezone.utc).isoformat().replace('+00:00','Z');expiry=datetime.fromtimestamp(now+300,timezone.utc).isoformat().replace('+00:00','Z')
        message=f"{urlparse(origin).netloc} wants you to sign in with your Ethereum account:\n{who}\n\nSign in to WorkLedger. This does not authorize a payment.\n\nURI: {origin}\nVersion: 1\nChain ID: {app.config['CHAIN_ID']}\nNonce: {nonce}\nIssued At: {issued}\nExpiration Time: {expiry}"
        with engine.begin() as c:c.execute(challenges.insert().values(id=nonce,address=who,message=message,expires=now+300,used=0))
        session['challenge']=nonce
        return jsonify(message=message,id=nonce)
    @app.post('/api/auth/verify')
    def verify():
        nonce=request.json.get('id','');signature=request.json.get('signature','')
        if nonce!=session.get('challenge'):return jsonify(error='Login challenge mismatch.'),401
        with engine.begin() as c:
            row=c.execute(select(challenges).where(challenges.c.id==nonce)).mappings().first()
            if not row or row['used'] or row['expires']<=int(time.time()):return jsonify(error='Login challenge expired or used.'),401
            try:recovered=Account.recover_message(encode_defunct(text=row['message']),signature=signature)
            except Exception:return jsonify(error='Invalid signature.'),401
            if recovered!=row['address']:return jsonify(error='Signature does not match wallet.'),401
            changed=c.execute(update(challenges).where(challenges.c.id==nonce,challenges.c.used==0).values(used=1))
            if changed.rowcount!=1:return jsonify(error='Challenge already consumed.'),401
            token=secrets.token_hex(32);c.execute(sessions.insert().values(id=hashlib.sha256(token.encode()).hexdigest(),address=recovered,expires=int(time.time())+3600));log(c,recovered,'login')
        session.clear();session['token']=token;session.permanent=True
        return jsonify(address=recovered)
    @app.post('/api/auth/logout')
    def logout():
        with engine.begin() as c:c.execute(delete(sessions).where(sessions.c.id==hashlib.sha256(session.get('token','').encode()).hexdigest()))
        session.clear();return jsonify(ok=True)
    @app.get('/api/me')
    @auth
    def me(who):
        chain();return jsonify(address=who,roles=contract('RoleRegistry').functions.roles(who).call(),creditWei=str(contract('PaymentEscrow').functions.credits(who).call()))
    @app.get('/api/agreements')
    def agreements_api():
        chain();offset=int(request.args.get('offset',0));limit=int(request.args.get('limit',12))
        if offset<0 or not 1<=limit<=50:raise ValueError('Invalid page bounds.')
        escrow=contract('PaymentEscrow');total=escrow.functions.nextId().call();end=min(total,offset+limit)
        return jsonify(items=[agreement(i) for i in range(offset,end)],total=total,nextOffset=end if end<total else None,timestamp=w3.eth.get_block('latest').timestamp,lockedWei=str(escrow.functions.lockedTotal().call()),creditWei=str(escrow.functions.creditTotal().call()))
    @app.route('/api/agreements/<int:i>/notes',methods=['GET','POST'])
    @auth
    def notes_api(who,i):
        chain();a=agreement(i)
        if not can_read(who,a):return jsonify(error='Agreement access denied.'),403
        if request.method=='POST':
            body=request.json.get('body','')
            if not isinstance(body,str) or not 1<=len(body.strip())<=2000:raise ValueError('Note must contain 1–2000 characters.')
            if who not in [a['customer'],a['provider'],a['auditor']]:return jsonify(error='Parties or assigned auditor only.'),403
            with engine.begin() as c:c.execute(notes.insert().values(network=network(),agreement=i,author=who,body=body.strip(),created=int(time.time())));log(c,who,'note:'+str(i))
            return jsonify(ok=True),201
        with engine.connect() as c:rows=c.execute(select(notes).where(notes.c.network==network(),notes.c.agreement==i).order_by(notes.c.id.desc()).limit(50)).mappings().all()
        return jsonify(items=[dict(r) for r in rows])
    @app.get('/api/audit')
    @auth
    def audit_api(who):
        if not (role(who,1) or role(who,8)):return jsonify(error='Auditor or administrator required.'),403
        with engine.connect() as c:rows=c.execute(select(audit).order_by(audit.c.id.desc()).limit(100)).mappings().all()
        return jsonify(items=[dict(r) for r in rows])
    @app.post('/api/events/sync')
    @auth
    def sync(who):
        chain();net=network();latest=w3.eth.block_number;start=app.config['DEPLOYMENT_BLOCK']
        with engine.connect() as c:prev=c.execute(select(cursors.c.block).where(cursors.c.network==net)).scalar()
        first=max(start,(prev-12) if prev is not None else start);last=min(latest,first+499)
        if first>last:return jsonify(scanned=0,hasMore=False)
        records=[]
        for name in NAMES:
            con=contract(name)
            for spec in ARTIFACTS[name]['abi']:
                if spec['type']!='event':continue
                for event in getattr(con.events,spec['name'])().get_logs(from_block=first,to_block=last):
                    data={k:Web3.to_hex(v) if isinstance(v,bytes) else str(v) if isinstance(v,int) else v for k,v in dict(event['args']).items()}
                    tx=Web3.to_hex(event['transactionHash']);records.append(dict(key=net+':'+tx+':'+str(event['logIndex']),network=net,block=event['blockNumber'],tx=tx,name=event['event'],data=json.dumps(data)))
        # Bounded overlap replaces recent records, handling shallow reorganizations.
        with engine.begin() as c:
            c.execute(delete(events).where(events.c.network==net,events.c.block>=first,events.c.block<=last))
            for record in records:c.execute(events.insert().values(**record))
            c.execute(delete(cursors).where(cursors.c.network==net));c.execute(cursors.insert().values(network=net,block=last));log(c,who,'sync:'+str(last))
        return jsonify(scanned=last-first+1,events=len(records),hasMore=last<latest,toBlock=last)
    @app.get('/api/events')
    def event_api():
        offset=int(request.args.get('offset',0))
        if offset<0:raise ValueError('Invalid offset.')
        with engine.connect() as c:rows=c.execute(select(events).where(events.c.network==network()).order_by(events.c.block.desc(),events.c.key).offset(offset).limit(50)).mappings().all()
        return jsonify(items=[dict(r) for r in rows],nextOffset=offset+50 if len(rows)==50 else None)
    @app.get('/deploy')
    def deploy():
        if not app.config['ENABLE_DEPLOY_UI']:return 'Deployment helper disabled.',404
        return render_template('deploy.html')
    @app.get('/api/artifacts')
    def artifacts():
        if not app.config['ENABLE_DEPLOY_UI']:return jsonify(error='Disabled'),404
        return jsonify(ARTIFACTS)
    return app

app=create_app()
if __name__=='__main__':app.run(host='127.0.0.1',port=int(os.getenv('PORT','5100')))
