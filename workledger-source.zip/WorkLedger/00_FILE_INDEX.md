# WorkLedger File Index

SC6113-DEVELOPMENT OF DECENTRALIZED APPLICATIONS

Liu Yanrong · Single-member group project

- Technical report: docs/WorkLedger_Technical_Report.pdf (13 pages)
- Presentation: docs/WorkLedger_Presentation.pptx (12 slides)
- User manual: docs/User_Manual.md
- Individual contribution: docs/Individual_Contribution.md
- Ten-minute live demonstration: docs/Live_Demonstration.md
- Testing report: docs/Testing_Report.md
- Deployment record: docs/Deployment_Record.md
- Architecture, contract, data, process and UI diagrams: docs/*.svg
- Solidity contracts: contracts/RoleRegistry.sol, contracts/PaymentEscrow.sol, contracts/DisputeBoard.sol
- ABI arrays: abi/
- Flask backend and database schema: app.py
- HTML: templates/; CSS: static/css/; JavaScript: static/js/
- Runtime dependencies: requirements.txt; development dependencies: requirements-dev.txt and package.json
- Setup instructions: README.md; cloud configuration: render.yaml
- Test source and measured results: tests/
- Browser screenshots: screenshots/
- Version-control history: source-history.bundle (clone with Git)
- Source repository: https://github.com/lyricleo99-cell/workledger-dapp
