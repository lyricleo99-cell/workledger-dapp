import pytest,time
from eth_account import Account
from eth_account.messages import encode_defunct
from sqlalchemy import select,update
from app import create_app
Account.enable_unaudited_hdwallet_features()
HEADERS={'X-Requested-With':'WorkLedger'}
@pytest.fixture
def application(w3,system,tmp_path):
 return create_app({'TESTING':True,'SECRET_KEY':'test-secret-not-for-deployment','DATABASE_URL':'sqlite:///'+str(tmp_path/'db.sqlite').replace(chr(92),'/'),'CHAIN_ID':1337,'ADDRESSES':{k:v.address for k,v in system.items()},'PUBLIC_ORIGIN':'http://localhost'},w3)
def login(app,index=1):
 c=app.test_client();key=Account.from_mnemonic('test test test test test test test test test test test junk',account_path=f"m/44'/60'/0'/0/{index}")
 ch=c.post('/api/auth/challenge',json={'address':key.address},headers=HEADERS).json
 sig=Account.sign_message(encode_defunct(text=ch['message']),key.key).signature.hex()
 r=c.post('/api/auth/verify',json={'id':ch['id'],'signature':sig},headers=HEADERS);assert r.status_code==200
 return c,ch,sig

def test_auth_signature_and_replay(application):
 c,ch,sig=login(application)
 assert c.get('/api/me').status_code==200
 assert c.post('/api/auth/verify',json={'id':ch['id'],'signature':sig},headers=HEADERS).status_code==401
 c.post('/api/auth/logout',json={},headers=HEADERS);assert c.get('/api/me').status_code==401

def test_signature_mismatch(application,w3):
 c=application.test_client();ch=c.post('/api/auth/challenge',json={'address':w3.eth.accounts[1]},headers=HEADERS).json
 bad=Account.create();sig=Account.sign_message(encode_defunct(text=ch['message']),bad.key).signature.hex()
 assert c.post('/api/auth/verify',json={'id':ch['id'],'signature':sig},headers=HEADERS).status_code==401

def test_expired_challenge(application,w3):
 c=application.test_client();ch=c.post('/api/auth/challenge',json={'address':w3.eth.accounts[1]},headers=HEADERS).json
 t=application.extensions['tables']['challenges']
 with application.extensions['db'].begin() as db:db.execute(update(t).values(expires=0))
 assert c.post('/api/auth/verify',json={'id':ch['id'],'signature':'0x00'},headers=HEADERS).status_code==401

@pytest.mark.parametrize('route',['/api/me','/api/audit','/api/agreements/0/notes'])
def test_anonymous_rejected(application,route):assert application.test_client().get(route).status_code==401

def test_origin_and_json_guards(application,w3):
 c=application.test_client()
 assert c.post('/api/auth/challenge',json={'address':w3.eth.accounts[1]}).status_code==403
 assert c.post('/api/auth/challenge',json={'address':w3.eth.accounts[1]},headers=dict(HEADERS,Origin='https://evil.example')).status_code==403

def test_private_notes_and_persistence(application,make):
 i=make();c,_,_=login(application,1)
 assert c.post(f'/api/agreements/{i}/notes',json={'body':'Delivery reference 123'},headers=HEADERS).status_code==201
 other,_,_=login(application,5);assert other.get(f'/api/agreements/{i}/notes').status_code==403
 provider,_,_=login(application,2);assert provider.get(f'/api/agreements/{i}/notes').json['items'][0]['body']=='Delivery reference 123'
 # Fresh Flask instance, same file database: data survives process recreation.
 fresh=create_app(dict(application.config),None)
 with fresh.extensions['db'].connect() as db:assert db.execute(select(fresh.extensions['tables']['notes'].c.body)).scalar()=='Delivery reference 123'
 fresh.extensions['db'].dispose()

def test_note_validation(application,make):
 i=make();c,_,_=login(application)
 for body in ['', 'x'*2001]:assert c.post(f'/api/agreements/{i}/notes',json={'body':body},headers=HEADERS).status_code==400

def test_audit_rbac(application):
 customer,_,_=login(application,1);assert customer.get('/api/audit').status_code==403
 auditor,_,_=login(application,3);assert auditor.get('/api/audit').status_code==200
 admin,_,_=login(application,0);assert len(admin.get('/api/audit').json['items'])>=3

def test_sync_idempotence(application,make):
 make();c,_,_=login(application)
 assert c.post('/api/events/sync',json={},headers=HEADERS).status_code==200
 first=c.get('/api/events').json['items']
 c.post('/api/events/sync',json={},headers=HEADERS)
 second=c.get('/api/events').json['items'];assert len(first)==len(second) and len(first)>0
 assert len({x['key'] for x in second})==len(second)

@pytest.mark.parametrize('query',['limit=0','limit=51','offset=-1','limit=abc'])
def test_pagination_validation(application,query):assert application.test_client().get('/api/agreements?'+query).status_code==400

def test_config_and_helper(application):
 c=application.test_client();data=c.get('/api/config').json
 assert 'RPC_URL' not in data and len(data['abi'])==3
 assert c.get('/deploy').status_code==404 and c.get('/api/artifacts').status_code==404
 assert c.get('/api/status').json['ready']
 assert c.get('/').headers['X-Frame-Options']=='DENY'
