import json,os,subprocess,sys,time
from pathlib import Path
import pytest
from web3 import Web3
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
@pytest.fixture(scope='session')
def w3():
    proc=subprocess.Popen(['node',str(ROOT/'scripts/local-chain.cjs')],env=dict(os.environ,TEST_RPC_PORT='19546'),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    w=Web3(Web3.HTTPProvider('http://127.0.0.1:19546'))
    for _ in range(100):
        if w.is_connected():break
        time.sleep(.1)
    else:proc.terminate();raise RuntimeError('Test chain unavailable')
    yield w
    proc.terminate();proc.wait(timeout=10)
def deploy(w):
    a=w.eth.accounts;out={}
    for name,args in [('RoleRegistry',[]),('PaymentEscrow',['RoleRegistry']),('DisputeBoard',['RoleRegistry','PaymentEscrow'])]:
        artifact=json.loads((ROOT/'artifacts'/f'{name}.json').read_text())
        c=w.eth.contract(abi=artifact['abi'],bytecode=artifact['bytecode'])
        receipt=w.eth.wait_for_transaction_receipt(c.constructor(*[out[x].address for x in args]).transact({'from':a[0]}))
        out[name]=w.eth.contract(address=receipt.contractAddress,abi=artifact['abi'])
    out['PaymentEscrow'].functions.bindBoard(out['DisputeBoard'].address).transact({'from':a[0]})
    reg=out['RoleRegistry'];reg.functions.enroll(2).transact({'from':a[1]});reg.functions.enroll(4).transact({'from':a[2]});reg.functions.setAuditor(a[3],True).transact({'from':a[0]})
    return out
@pytest.fixture
def system(w3):return deploy(w3)
@pytest.fixture
def make(w3,system):
    def create(fund=True,delay=3600):
        c=system['PaymentEscrow'];i=c.functions.nextId().call();a=w3.eth.accounts
        c.functions.createAgreement(a[2],a[3],10**15,w3.eth.get_block('latest').timestamp+delay,b'1'*32).transact({'from':a[1]})
        if fund:c.functions.fundAgreement(i).transact({'from':a[1],'value':10**15})
        return i
    return create
@pytest.fixture
def advance(w3):
    def go(seconds):w3.provider.make_request('evm_increaseTime',[seconds]);w3.provider.make_request('evm_mine',[])
    return go
