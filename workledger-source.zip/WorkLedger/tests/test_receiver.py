import json,pytest
from pathlib import Path
@pytest.mark.parametrize('reject,attack',[(True,False),(False,True)])
def test_receiver_failure_and_reentry(w3,system,reject,attack):
 artifact=json.loads((Path(__file__).parent/'Receiver.json').read_text());a=w3.eth.accounts;e=system['PaymentEscrow']
 f=w3.eth.contract(abi=artifact['abi'],bytecode=artifact['bytecode']);receipt=w3.eth.wait_for_transaction_receipt(f.constructor(system['RoleRegistry'].address,e.address).transact({'from':a[0]}));r=w3.eth.contract(address=receipt.contractAddress,abi=artifact['abi'])
 e.functions.createAgreement(r.address,a[3],1000,w3.eth.get_block('latest').timestamp+3600,b'1'*32).transact({'from':a[1]});e.functions.fundAgreement(0).transact({'from':a[1],'value':1000});r.functions.deliver(0).transact({'from':a[0]});e.functions.approveWork(0).transact({'from':a[1]});r.functions.configure(reject,attack).transact({'from':a[0]})
 if reject:
  with pytest.raises(Exception):r.functions.collect().transact({'from':a[0]})
  assert e.functions.credits(r.address).call()==1000 and e.functions.creditTotal().call()==1000
 else:
  r.functions.collect().transact({'from':a[0]});assert not r.functions.reentrySucceeded().call();assert w3.eth.get_balance(r.address)==1000 and e.functions.credits(r.address).call()==0
