// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;
interface IAccess { function enroll(uint8) external; }
interface IEscrow { function submitWork(uint256,bytes32) external; function withdrawCredit() external; }
contract Receiver {
 IEscrow public escrow; bool public reject; bool public attack; bool public reentrySucceeded;
 constructor(address r,address e){IAccess(r).enroll(4);escrow=IEscrow(e);}
 function deliver(uint256 id) external {escrow.submitWork(id,bytes32(uint256(1)));}
 function configure(bool r,bool a) external {reject=r;attack=a;}
 function collect() external {escrow.withdrawCredit();}
 receive() external payable {require(!reject,"Reject");if(attack){(reentrySucceeded,)=address(escrow).call(abi.encodeWithSignature("withdrawCredit()"));}}
}
