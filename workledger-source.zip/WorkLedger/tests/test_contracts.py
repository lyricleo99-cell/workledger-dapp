import pytest

def test_roles(w3,system):
 r=system['RoleRegistry'];a=w3.eth.accounts
 for v in [0,1,8,255]:
  with pytest.raises(Exception):r.functions.enroll(v).transact({'from':a[4]})
 with pytest.raises(Exception):r.functions.setAuditor(a[4],True).transact({'from':a[1]})
 r.functions.setAuditor(a[3],False).transact({'from':a[0]});assert not r.functions.hasRole(a[3],8).call()

@pytest.mark.parametrize('kind',['same','auditor','zero','past','empty','unregistered'])
def test_invalid_creation(w3,system,kind):
 a=w3.eth.accounts;args=[a[2],a[3],100,w3.eth.get_block('latest').timestamp+100,b'1'*32]
 if kind=='same':args[0]=a[1]
 if kind=='auditor':args[1]=a[1]
 if kind=='zero':args[2]=0
 if kind=='past':args[3]=0
 if kind=='empty':args[4]=bytes(32)
 if kind=='unregistered':args[0]=a[8]
 with pytest.raises(Exception):system['PaymentEscrow'].functions.createAgreement(*args).transact({'from':a[1]})

def test_draft_amend_cancel(w3,system,make):
 a=w3.eth.accounts;e=system['PaymentEscrow'];i=make(False)
 e.functions.amendAgreement(i,200,w3.eth.get_block('latest').timestamp+500,b'2'*32).transact({'from':a[1]});assert e.functions.getAgreement(i).call()[3]==200
 e.functions.cancelAgreement(i).transact({'from':a[1]})
 with pytest.raises(Exception):e.functions.fundAgreement(i).transact({'from':a[1],'value':200})

@pytest.mark.parametrize('account,value',[(1,1),(2,10**15),(1,10**15+1)])
def test_funding_validation(w3,system,make,account,value):
 i=make(False)
 with pytest.raises(Exception):system['PaymentEscrow'].functions.fundAgreement(i).transact({'from':w3.eth.accounts[account],'value':value})

def test_payment_and_withdrawal(w3,system,make):
 a=w3.eth.accounts;e=system['PaymentEscrow'];i=make()
 e.functions.submitWork(i,b'2'*32).transact({'from':a[2]});e.functions.approveWork(i).transact({'from':a[1]})
 assert e.functions.credits(a[2]).call()==10**15 and e.functions.lockedTotal().call()==0
 before=w3.eth.get_balance(a[2]);r=w3.eth.wait_for_transaction_receipt(e.functions.withdrawCredit().transact({'from':a[2]}))
 assert w3.eth.get_balance(a[2])==before+10**15-r.gasUsed*r.effectiveGasPrice
 assert e.functions.creditTotal().call()==0 and w3.eth.get_balance(e.address)==0
 with pytest.raises(Exception):e.functions.withdrawCredit().transact({'from':a[2]})

def test_revision(w3,system,make):
 a=w3.eth.accounts;e=system['PaymentEscrow'];i=make();e.functions.submitWork(i,b'2'*32).transact({'from':a[2]});e.functions.requestRevision(i).transact({'from':a[1]});assert e.functions.getAgreement(i).call()[6]==1
 e.functions.submitWork(i,b'3'*32).transact({'from':a[2]});assert e.functions.getAgreement(i).call()[8]==b'3'*32

def test_timeout_claim(w3,system,make,advance):
 a=w3.eth.accounts;e=system['PaymentEscrow'];i=make();e.functions.submitWork(i,b'2'*32).transact({'from':a[2]})
 with pytest.raises(Exception):e.functions.claimAfterReview(i).transact({'from':a[2]})
 advance(259201);e.functions.claimAfterReview(i).transact({'from':a[2]});assert e.functions.credits(a[2]).call()==10**15

def test_refund(w3,system,make,advance):
 a=w3.eth.accounts;e=system['PaymentEscrow'];i=make(delay=60)
 with pytest.raises(Exception):e.functions.refundExpired(i).transact({'from':a[1]})
 advance(61);e.functions.refundExpired(i).transact({'from':a[1]});assert e.functions.credits(a[1]).call()==10**15

@pytest.mark.parametrize('allocation',[0,400000000000000,1000000000000000])
def test_dispute_and_isolation(w3,system,make,allocation):
 a=w3.eth.accounts;e=system['PaymentEscrow'];b=system['DisputeBoard'];i=make();j=make();b.functions.openDispute(i,b'3'*32).transact({'from':a[1]})
 for actor,value in [(a[4],allocation),(a[3],10**15+1)]:
  with pytest.raises(Exception):b.functions.resolveDispute(i,value,b'4'*32).transact({'from':actor})
 assert b.functions.rulings(i).call()==bytes(32)
 b.functions.resolveDispute(i,allocation,b'4'*32).transact({'from':a[3]})
 assert e.functions.credits(a[2]).call()==allocation and e.functions.credits(a[1]).call()==10**15-allocation
 assert e.functions.getAgreement(j).call()[6]==1
 assert e.functions.lockedTotal().call()+e.functions.creditTotal().call()==w3.eth.get_balance(e.address)
 with pytest.raises(Exception):b.functions.resolveDispute(i,0,b'4'*32).transact({'from':a[3]})

def test_auditor_removal_preserves_existing_agreement(w3,system,make):
 a=w3.eth.accounts;i=make();system['RoleRegistry'].functions.setAuditor(a[3],False).transact({'from':a[0]});b=system['DisputeBoard'];b.functions.openDispute(i,b'3'*32).transact({'from':a[2]});b.functions.resolveDispute(i,0,b'4'*32).transact({'from':a[3]})
 with pytest.raises(Exception):make()

@pytest.mark.parametrize('method,args',[('submitWork',[b'2'*32]),('approveWork',[]),('requestRevision',[]),('refundExpired',[]),('flagDispute',['0x0000000000000000000000000000000000000001']),('applyResolution',[0])])
def test_unauthorized(w3,system,make,method,args):
 i=make()
 with pytest.raises(Exception):getattr(system['PaymentEscrow'].functions,method)(i,*args).transact({'from':w3.eth.accounts[5]})

def test_binding_immutable(w3,system):
 with pytest.raises(Exception):system['PaymentEscrow'].functions.bindBoard(system['DisputeBoard'].address).transact({'from':w3.eth.accounts[0]})

def test_dispute_freezes_refund(w3,system,make,advance):
 a=w3.eth.accounts;i=make();system['DisputeBoard'].functions.openDispute(i,b'3'*32).transact({'from':a[1]});advance(4000)
 with pytest.raises(Exception):system['PaymentEscrow'].functions.refundExpired(i).transact({'from':a[1]})
