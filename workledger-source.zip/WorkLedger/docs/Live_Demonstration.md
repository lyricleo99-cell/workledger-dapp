# WorkLedger Ten Minute Live Demonstration

Author: Liu Yanrong

Format: live demonstration, one of the two formats specified in the assignment brief. This document is the demonstration sequence, not a claim that an assessed presentation has already taken place.

## 0:00–1:00 Problem and roles

Describe the small service engagement and distinguish prefunding from a normal invoice reminder. Show the four roles. Explain that the example accounts represent business actors in a single-member project.

## 1:00–2:00 Architecture and authentication

Show the three contract addresses and the architecture diagram. Connect the customer account and sign the domain-bound login message. Explain that signing in is off-chain and does not move funds.

## 2:00–3:30 Agreement and custody

Create a small test agreement with a registered provider and independent auditor. Show the scope hash, estimate gas and confirm. Fund the exact amount. Show the state transition and locked balance.

## 3:30–5:00 Delivery and payment

Switch to the provider, sign in and submit a delivery reference. Switch to the customer and approve. Return to the provider and withdraw credit. Show confirmation and the activity ledger.

## 5:00–6:30 Dispute scenario

Use a separate funded agreement. Open a dispute, then sign in as its assigned auditor and allocate a portion to the provider. Show the remaining customer credit. Explain why the administrator cannot take the escrow.

## 6:30–7:30 Persistent notes and permissions

Save an agreement note. Show that the counterparty can read it and an unrelated account cannot. Show the auditor audit log. Relate these screens to database persistence and role checks.

## 7:30–8:30 Failure and timeout evidence

Show automated results for incorrect amounts, unauthorized calls, replayed login, expired delivery and three-day review. The deterministic local tests advance chain time; the public network does not. Show failed receiver and reentrancy results.

## 8:30–9:30 Measurements

Show fourteen recorded transaction types, gas samples and bytecode optimization. Explain the local read benchmark and its scope. Present the illustrative 30-day versus three-day payment-window model as an assumption-based scenario.

## 9:30–10:00 Conclusion

Summarize custody, human arbitration trust and off-chain persistence. Explain limitations without claiming production financial approval or measured commercial savings.

## Local rehearsal environment

Start npm run chain and python scripts/local_preview.py in separate terminals. The browser test provides a repeatable isolated-adapter workflow and screenshots. For a manual wallet demonstration, use distinct disposable accounts on the chosen test network with the necessary customer, provider and auditor roles. Account secrets are never entered into Flask.
