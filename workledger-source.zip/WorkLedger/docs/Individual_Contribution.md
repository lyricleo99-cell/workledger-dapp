# Individual Contribution Report

Course: SC6113-DEVELOPMENT OF DECENTRALIZED APPLICATIONS

Project: WorkLedger Enterprise Escrow DApp

Author: Liu Yanrong

Project arrangement: single-member group project. There are no additional group members or allocated shares.

## Responsibility and evidence

The project scope covers problem analysis and source evaluation, requirements, the three-contract architecture, role and custody rules, Flask authentication and database integration, responsive UI, transaction signing and gas estimation, automated verification and technical documentation. Related evidence is organised in the source directories, tests/ and docs/.

The technical report evaluates the implementation and states its measurement boundaries. The user manual describes the delivered functions. The presentation and live demonstration guide explain the customer, provider, auditor and administrator scenarios. These are application roles, not project contributors.

## Development record

Git commits record actual implementation milestones. The repository history covers contract/API foundations, the interface and local evaluation, and documentation. No historical work dates, stakeholder interviews or contributions from other people are attributed. Source and dependency licenses remain in the package.
