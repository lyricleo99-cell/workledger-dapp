# Testing and Evaluation Record

Environment: local Ganache, chain ID 1337, Python 3.11, Solidity 0.8.30 with 200 optimizer runs and Paris EVM target.

- 45 automated Python tests passed (27 state/contract, 16 API/auth/database, 2 adversarial receiver).
- 14 browser checks passed with an isolated EIP-1193 test wallet.
- 14 distinct application transaction types have successful local receipts.
- 40 bounded read requests with concurrency four returned HTTP 200; median 378.47 ms and p95 422.94 ms.
- Runtime bytecode reductions: escrow 53.4%, registry 55.3%, board 49.1%.

The raw records are results.xml, browser-results.json, gas-results.json, performance-results.json and optimization-results.json in tests/. Screenshots record the local browser run. Blockchain write receipts and persistence assertions provide behavior evidence rather than static source inspection.

The browser adapter is not a real MetaMask extension. Measurements do not establish cloud throughput or business savings. Public deployment is recorded independently in Deployment_Record.md.

## Dependency review

The browser ethers bundle is pinned to 6.17.0 after dependency review. The Ganache/compiler development toolchain has unresolved transitive dependency advisories and is confined to loopback-only local testing. Node development dependencies are not installed by the Python cloud build. These findings are not presented as a clean security audit.
