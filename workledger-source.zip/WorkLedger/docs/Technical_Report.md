# WorkLedger
Design and Implementation of an Enterprise Escrow DApp
SC6113-DEVELOPMENT OF DECENTRALIZED APPLICATIONS
Group Project Report
Liu Yanrong
Single-member implementation
<!-- PAGE -->
## 1 Introduction and real-world problem
WorkLedger addresses payment uncertainty in small service engagements between a business customer and an independent provider. The customer needs a verifiable delivery process; the provider needs assurance that agreed funds are available. A disputed deliverable also needs a documented decision rather than an untraceable change to a spreadsheet. The implemented system combines prefunded escrow, delivery hashes, a fixed review window and an independently assigned auditor.
The UK Department for Business and Trade commissioned research published on 30 July 2025 estimating that late payments cost the UK economy almost GBP 11 billion annually and contribute to approximately 14,000 business closures per year [1]. These estimates establish the importance of payment friction; they do not establish the effectiveness of this prototype or describe all countries and sectors. The research combines survey evidence and economic analysis. WorkLedger targets a narrower problem: small, explicitly agreed service jobs where advance funding is feasible.
### Stakeholders
Customers fund an agreement and inspect delivery before release. Providers submit evidence and withdraw payment. Auditors adjudicate disputes under the allocation authority agreed by both counterparties. The administrator appoints auditors for new agreements but has no direct withdrawal or arbitrary balance-editing function. One person can operate different test accounts during a demonstration; these represent distinct business actors, not additional project authors.
### Blockchain suitability
A centralized marketplace can implement the same screens at lower operational cost. Blockchain is useful here when parties want independently inspectable custody and settlement rules across organisational boundaries. It cannot verify work quality, guarantee fair arbitration or remove reliance on the web host and RPC provider. Upfront funding ties up customer liquidity and is inappropriate for some commercial arrangements.
<!-- PAGE -->
## 2 Requirements and transaction coverage
Functional requirements are wallet authentication, role-aware actions, independently held balances, delivery review, disputes, withdrawals, private notes and an event ledger. Non-functional requirements include exact integer accounting, bounded API reads, restart-persistent business data and a usable narrow-screen layout. Security requirements include nonce expiry, replay prevention, access checks at both API and contract boundaries, and failure-safe withdrawals.
### Four application roles
Administrator manages auditor eligibility and reads the audit trail. Customer creates, amends, cancels and funds agreements, then approves or requests revision. Provider delivers work and claims eligible funds. Auditor resolves only agreements explicitly assigned to that address. Customer and provider enrollment is self-service; auditor eligibility is administered. Existing appointments survive removal from the auditor registry, preventing removal from silently stranding an existing dispute.
### Fourteen blockchain transaction types
1. enroll: register a customer or provider role.
2. setAuditor: grant or remove eligibility for new auditor assignments.
3. createAgreement: commit counterparties, value, deadline and terms hash.
4. amendAgreement: update an unfunded draft.
5. cancelAgreement: close an unfunded draft.
6. fundAgreement: deposit exactly the agreed value.
7. submitWork: commit delivery evidence.
8. requestRevision: return a timely submission to funded status.
9. approveWork: release payment into provider credit.
10. claimAfterReview: release after an unchallenged three-day review period.
11. refundExpired: refund a funded agreement without timely submission.
12. openDispute: freeze settlement for arbitration.
13. resolveDispute: allocate funds between counterparties.
14. withdrawCredit: withdraw an available credit balance.
All fourteen operations have successful local transaction receipts in tests/gas-results.json. Contract deployment and one-time board binding are additional setup transactions and are not counted toward this total.
<!-- PAGE -->
## 3 System architecture
The browser renders the workspace, obtains a wallet signature for login, estimates gas and requests transaction signatures. Flask verifies login signatures, enforces private-data access and returns public chain reads. SQLAlchemy supports SQLite for local persistence and PostgreSQL for cloud deployment. The database stores authentication challenges, sessions, private notes, application audit entries and indexed contract events. It never stores wallet keys or authoritative escrow balances.
[DIAGRAM architecture]
Figure 1. System architecture and trust boundaries.
### Read and write paths
A payment action travels from the browser through ethers and MetaMask to the configured chain. Flask does not submit payment transactions. After a receipt, the browser refreshes chain-backed agreement data. A note action instead travels through the authenticated REST API into the database. Hashes on chain prove consistency with a supplied document; the system does not guarantee document availability or truth.
The wallet role is checked again by the contract for each relevant action. The API reads current role state for auditor and administrator endpoints. Private-note access is based on the agreement parties and its assigned auditor; the administrator has read access for support, but cannot post a note as a party. Browser visibility is a usability control, not the authorization boundary.
### Deployment structure
Gunicorn serves Flask behind the cloud HTTPS endpoint. PUBLIC_ORIGIN fixes the login domain and URI. SECRET_KEY signs session cookies and must remain stable across worker processes. DATABASE_URL selects persistent SQL storage independently of the web instance filesystem. ABI and bytecode are generated from the same Solidity sources.
<!-- PAGE -->
## 4 Smart contract interaction and lifecycle
RoleRegistry stores bitmask roles and an immutable administrator. PaymentEscrow owns ETH and agreement state. DisputeBoard holds reason and ruling hashes and invokes restricted escrow transitions. The escrow board address can be bound once by the registry administrator. The DisputeBoard constructor checks that its escrow and registry agree.
[DIAGRAM contracts]
Figure 2. Interacting contracts. Calls that affect custody are restricted to the bound board.
[DIAGRAM flow]
Figure 3. Agreement lifecycle, including review, refund and dispute branches.
A draft can be amended or cancelled only before funding. Funding requires an exact amount and a future deadline. Only the named provider can submit a nonzero delivery digest by the deadline. A customer can approve, request a revision within both the delivery deadline and review period, or open a dispute. A provider can claim after three days without a dispute. A funded agreement without submission can be refunded after the deadline. A dispute prevents ordinary settlement; the assigned auditor allocates any amount from zero to the full escrow to the provider, with the remainder credited to the customer.
Settlement records credits without calling either counterparty. Withdrawal is a separate operation. The administrator cannot change the selected auditor or rewrite funded terms. This reduces administrative power but means lost auditor keys can leave a dispute unresolved; there is no hidden emergency override.
<!-- PAGE -->
## 5 Security design
### Custody and authorization
Each agreement records its customer, provider, auditor and amount. Customer and provider must differ, and the auditor must differ from both. State checks reject duplicate settlement. The liability invariant is lockedTotal plus creditTotal less than or equal to contract ETH holdings. Equality holds for ordinary accepted flows; forced ETH transfers may create surplus. A failed withdrawal rolls back the user's credit and the global credit total.
Withdrawals use a reentrancy guard, clear accounting before the external call and revert if the receiver rejects ETH. Adversarial receiver tests check both a failing receiver and attempted recursive withdrawal. A receiving contract cannot collect the same credit twice. This follows the checks-effects-interactions guidance in Solidity documentation [2]. It is implementation testing, not an independent security audit.
### Wallet authentication
The server issues a random, five-minute, domain- and chain-bound challenge using an ERC-4361-style message. The EIP-191 signature is recovered and compared with the challenge address. A browser session binds the challenge request to verification. Consumption uses a conditional database update so a used nonce cannot create a second session. Session tokens are randomly generated, hashed in SQL and expire after one hour. Logout deletes the server-side session. This implementation supports externally owned accounts, not EIP-1271 contract-wallet validation [3].
### Web controls
State-changing API calls require JSON and a custom application header; supplied Origin headers must match PUBLIC_ORIGIN. Cookies are HttpOnly and SameSite Strict, and Secure under HTTPS. A same-origin content security policy limits script sources. Notes are rendered as text, SQL queries are parameterized, request size is bounded, and raw RPC exceptions are withheld. Challenge issuance has a database-backed per-source-IP rate limit. Production protection still requires edge rate limiting and operational monitoring.
<!-- PAGE -->
## 6 Backend and persistent data
Flask exposes public configuration, readiness, agreement reads and indexed events. Authenticated endpoints support notes, index synchronization and role-gated audit reads. Public health reports database reachability; blockchain readiness separately checks chain identity, code existence and the board binding. No API response contains an RPC credential or a private signing key.
[DIAGRAM data]
Figure 4. Database records and their relationship to on-chain agreements.
Challenges contain the exact message, account, expiry and consumption flag. Sessions store a hashed token, account and expiry. Notes include a network namespace, agreement ID, author, body and timestamp. Audit entries record actor, action and time. Chain events store network, transaction hash, log index, block, event name and arguments. A cursor tracks the latest indexed range. Request-limit records support login throttling.
Notes and events are namespaced by chain ID and escrow address so a new deployment cannot accidentally display records from another contract. Database recreation is not part of ordinary application startup; schema creation is idempotent. A test recreates the Flask application against the same SQLite file and verifies that saved notes remain available. PostgreSQL uses the same SQLAlchemy schema and is the cloud persistence option.
### Bounded indexing
A sync scans at most 500 blocks and overlaps the previous twelve blocks. Recent cached records are replaced, so shallow reorganizations can be reconciled. Repeated syncs do not duplicate the same transaction-log record. Events are an informational cache; live contract reads determine balances and action eligibility. Deep reorganizations require a cursor reset and rebuild. Parallel sync conflicts can fail safely as database transactions rather than partially commit, but a production indexer should use one scheduled worker and explicit locking.
<!-- PAGE -->
## 7 Interface and usability
The workspace separates portfolio overview, project agreements, the activity ledger, and access/audit tools. Agreement cards show the amount, counterparties, delivery deadline, status and terms digest. The status chart describes loaded agreements, while locked escrow is read from the contract's global total. This distinction avoids presenting a partial page as a complete distribution.
[SCREENSHOT 01-overview.png]
Figure 5. Actual local-browser overview with seeded agreements on chain 1337.
[DIAGRAM ui]
Figure 6. Interface flow for authentication and a payment action.
Each action is prepared in a dialog. Client-side amount parsing converts decimal ETH to integer Wei, and address/deadline checks run before gas estimation. Estimation is a read-only simulation, followed by a separate wallet-confirmation control. Editing form values invalidates the estimate. Wallet account or chain changes clear the application session and close private dialogs.
Messages distinguish signature rejection, transaction submission, receipt confirmation and service errors. A submitted hash is retained in browser storage and rechecked at the next login. One block inclusion is explicitly distinguished from finality. Receipt replacement handling and cross-device pending tracking are limited. The interface uses labeled form controls, native dialogs and text status indicators. The 390-pixel browser check verified no page-wide horizontal overflow; the event table can scroll independently.
<!-- PAGE -->
## 8 Testing and scenario validation
The test environment uses an isolated Ganache EVM with deterministic public test accounts. Contract and backend tests run against fresh deployments. Browser tests use an injected EIP-1193 adapter that signs test login messages and sends real local transactions; they do not automate a real MetaMask extension. No mainnet funds or user private keys are used.
### Executed checks
45 automated Python tests passed: 27 contract/state tests, 16 authentication/API/database tests and 2 adversarial receiver tests. The suite covers invalid roles and creation terms, exact funding, unauthorized transitions, revision, review timeout, late-delivery refund, split arbitration, balance isolation, binding immutability, signature mismatch, expiry, replay, origin/header controls, note persistence, note authorization, pagination and event idempotence.
14 browser checks passed. They include public reads, signed customer login, role-restricted controls, gas estimation, agreement creation, exact funding, a private note, provider delivery, customer approval, provider withdrawal, event indexing, auditor access, administrator controls and mobile layout. The check list groups related assertions; its raw evidence is tests/browser-results.json.
### Scenario-based validation
The accepted-delivery scenario credits the provider and verifies the recipient's ending balance after gas. The revision scenario preserves the agreed custody amount through resubmission. The no-delivery scenario returns funds only after the deadline. The customer-silence scenario releases funds only after the three-day review window. Dispute scenarios test zero, partial and full provider allocations while another funded agreement remains untouched. A rejecting receiver leaves credit intact; a reentering receiver receives only its recorded credit.
These scenarios substitute for stakeholder interviews in this implementation's validation design, as permitted by the brief. They establish executable behavior under the stated assumptions. They do not measure real user satisfaction, dispute fairness or commercial adoption.
<!-- PAGE -->
## 9 Gas and performance evaluation
The compiler is Solidity 0.8.30, optimization enabled with 200 runs, targeting Paris EVM. Runtime code size fell from 16,799 to 7,832 bytes for PaymentEscrow (53.4%), from 3,210 to 1,634 bytes for DisputeBoard (49.1%), and from 2,884 to 1,288 bytes for RoleRegistry (55.3%). These are bytecode-size comparisons, not measured percentage fee savings.
[GAS]
Gas figures are actual local receipt measurements. Storage history affects costs: a first credit or first write can cost more than a later write. The recorded sample for each operation is identified by transaction hash in tests/gas-results.json. Fourteen distinct application transaction types were executed. ETH fee depends on gas price and is not inferred from local balances.
### Read API measurement
A bounded local test issued 40 agreement-read requests with concurrency four against nine agreements. All 40 returned HTTP 200. Median response time was 378.47 ms, p95 was 422.94 ms, and observed throughput was 10.46 requests per second over 3.826 seconds. The sample uses the Flask development server and local Ganache; it is neither a cloud SLA nor an enterprise capacity estimate.
Agreement reads are limited to 50 records per call; the interface uses 12. Note reads return the latest 50 records and event reads return 50 per page. These limits bound individual response work but do not make total storage growth bounded. A production design would add migrations, retention, database indexes, read caching and dedicated event workers. Higher concurrency and RPC latency need separate deployment-specific measurement.
<!-- PAGE -->
## 10 Impact evaluation and practical constraints
The measurable technical indicators are conservation of escrow liabilities, prevention of unauthorized settlement, completion of fourteen transaction types, persistent notes, and bounded read response time. All are linked to executed tests or measurements. The business hypothesis is that prefunding reduces uncertainty about whether money is available and that a committed review window limits indefinite customer silence.
### Explicit scenario model
For an illustrative service payment with an assumed 30-day post-delivery wait, an unchallenged three-day review window reduces the contractual wait to credit eligibility by 27 days, or 90%. The 30-day baseline is a scenario assumption, not a measured industry average. The model excludes pre-delivery funding duration, disputes, gas, wallet availability, chain confirmation time and the separate withdrawal transaction. No realised cost saving is claimed.
Transparency can be evaluated by matching each state change to a transaction receipt and event. The local demonstration records fourteen transaction types with successful receipts. Accessibility is assessed through responsive layout and clear status text, not a participant satisfaction score. Provider income and customer acceptance would require field evaluation before commercial claims were justified.
### Ethics and feasibility
On-chain addresses, values, deadlines and hashes are public. Hashing a predictable description is not encryption. Confidential documents should remain outside public metadata, and storage permissions must be agreed. Private notes are access-controlled but not encrypted at rest by the application. An auditor is a trusted decision maker; collusion, bias, unavailable keys and inaccurate evidence remain material risks.
The prototype uses Sepolia-compatible test ETH. Real-money operation would require jurisdiction-specific assessment of custody, dispute-resolution terms, tax, privacy, consumer rights and any applicable payment or financial-services requirements. Technical escrow does not itself establish regulatory authorization. Volatile native assets, wallet usability, funding requirements and independent auditing are barriers to adoption.
<!-- PAGE -->
## 11 Deployment and project management
The deployable application uses a Flask/Gunicorn service with external PostgreSQL storage. A Render blueprint defines application and database configuration. Local operation uses SQLite; a disposable cloud filesystem is unsuitable for durable notes and sessions. A free PostgreSQL 18 instance was created in Oregon on 14 October 2026; its displayed expiry is 13 November 2026. Free-tier lifetime and backup limits constrain demonstration availability [4]. The local verification does not establish public-cloud or public-testnet deployment.
### Contract deployment sequence
RoleRegistry is deployed first, PaymentEscrow receives its address, and DisputeBoard receives both addresses. The administrator binds the board once. A MetaMask deployment page performs these as four separate signed transactions and stores successful step addresses in browser storage for resumption. Environment configuration includes all three contract addresses, chain ID, deployment start block, RPC URL, public origin, session secret and database URL. The helper is disabled in the normal configuration.
### Professional development practice
The source package contains the Solidity sources and ABIs, Flask application, frontend, test sources and evidence, dependency declarations, deployment configuration and reproducible local preview. Version-control commits record completed implementation stages using their actual creation time. Generated database files, secrets and dependency folders are excluded from the submission archive. A file index identifies each deliverable.
### Individual contribution
This is a single-member group project by Liu Yanrong. The project scope includes requirements analysis, architecture, contract and API integration, interface development, test evaluation and documentation. Separate customer, provider, auditor and administrator accounts are application roles used for scenario testing; they are not team members. The individual contribution report describes the same ownership without inventing a group allocation or interview evidence.
<!-- PAGE -->
## 12 Conclusion
WorkLedger implements a complete local escrow workflow across three interacting contracts, a wallet-authenticated Flask service, persistent SQL data and a responsive web interface. Four roles separate commercial and administrative responsibilities. Fourteen application transaction types cover enrollment, agreement management, delivery, dispute resolution and withdrawal. Forty-five automated Python tests and fourteen browser checks support the implemented behavior.
The main innovation is the combination of prefunding, an explicitly assigned independent auditor, a time-bounded review path and a private business-note layer. Custody rules remain inspectable even though off-chain service availability and human arbitration introduce trust dependencies. Measured bytecode reductions and bounded API tests provide reproducible engineering evidence. Commercial impact is expressed as a transparent scenario model, with no unsupported claims of real customer savings.
### References
[1] Department for Business and Trade. Late payments research: impact on the UK economy. Published 30 July 2025. https://www.gov.uk/government/publications/late-payments-research-impact-on-the-uk-economy
[2] Solidity. Security Considerations. https://docs.soliditylang.org/en/latest/security-considerations.html
[3] Ethereum Improvement Proposals. ERC-4361: Sign-In with Ethereum. https://eips.ethereum.org/EIPS/eip-4361
[4] Render. Deploy for Free. https://render.com/docs/free
[5] SC6113 Group Project. Supplied coursework brief: Enterprise Financial Decentralized Application. Requirements and assessment rubric.
### Evidence index
Test results: tests/results.xml and tests/browser-results.json. Transaction measurements: tests/gas-results.json. Optimization comparison: tests/optimization-results.json. Read measurements: tests/performance-results.json. Screenshots: screenshots/. All numerical implementation results in this report refer to the local test environment unless explicitly stated otherwise.
