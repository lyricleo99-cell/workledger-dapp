# Deployment Record

## Source repository

https://github.com/lyricleo99-cell/workledger-dapp

Repository created on 14 October 2026. The supplied source archive preserves the application directory structure. Local implementation history is included in source-history.bundle.

## Verified development environment

Local application: http://127.0.0.1:5100

Blockchain: Ganache chain 1337, three deployed contracts, one-time board binding and executed agreement scenarios. Local addresses and hashes are not Sepolia deployment evidence.

Database: SQLite file storage. Persistence across application recreation is verified by the API tests.

## Render infrastructure

A free PostgreSQL 18 instance named workledger-db was created in Oregon on 14 October 2026 and reported Available. Its expiry date is 13 November 2026. Database credentials are excluded from the submission. This infrastructure record does not establish an application connection test.

## Verification scope

The application and contract workflow are verified locally. No public application URL or Sepolia contract address is asserted in this edition. Public application hosting and wallet-signed deployment are distinct from source compilation and local testing.
