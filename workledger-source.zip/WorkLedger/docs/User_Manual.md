# WorkLedger User Manual

## Sign in

Open the deployment URL in a browser with MetaMask. Connect & sign in requests access to the chosen account, checks the configured network and displays a login signature. The signature authenticates the account and does not authorize payment. Session duration is one hour. Changing account or network signs out of the application.

## Business roles

Join as customer or Join as provider enrolls that role through a blockchain transaction. The same address can hold both roles, but it cannot be both counterparties in one agreement. The administrator uses Access & audit to grant auditor eligibility. The selected auditor must differ from both counterparties.

## Create and fund

A customer selects New agreement, enters provider and auditor addresses, amount, future deadline and a scope description. The scope is hashed; its full text is not automatically persisted. Counterparties retain the agreed description privately or in agreement notes. Estimate gas simulates the transaction. Confirm in MetaMask submits it. A draft can be amended or cancelled. Fund escrow transfers exactly its agreed amount.

## Deliver and review

The named provider selects Submit work and enters an evidence reference. The reference is hashed on chain. A customer may approve or request revision before the relevant deadlines. Approval credits the provider. After three days from submission without a dispute, the provider can Claim after review. If no work was submitted by the delivery deadline, the customer can Refund expired delivery. Returned amounts become withdrawable credit.

## Disputes

Either party can Open dispute while the agreement is funded or within its submission review window. The reason digest is public; supporting details can be placed in private notes. Ordinary settlement is frozen. The originally assigned auditor selects Resolve dispute, enters the provider allocation and ruling description, estimates gas and signs. The remainder is credited to the customer. Both parties withdraw separately.

## Notes and logs

Notes are available to the two counterparties, assigned auditor and administrator; only parties and the assigned auditor can post. Sync events retrieves a bounded range of contract logs. More than 500 blocks requires another sync. Audit entries show authentication, note and indexing actions to administrators and registered auditors.

## Withdraw

Withdraw credit transfers the full available credit to the connected wallet. It does not withdraw locked agreements. Gas is paid by the wallet, so the account needs test ETH in addition to any escrow amount. Failed recipient transfers leave the credit available.

## Status and recovery

Submitted means broadcast, not success. Confirmed means one block inclusion. After a timeout, the stored transaction hash can be checked on reconnection and in Sepolia Etherscan. A role or state rejection should be resolved by checking the current agreement and account. Service unavailable indicates a backend, database or RPC read failure. The application never requests a recovery phrase or private key.
