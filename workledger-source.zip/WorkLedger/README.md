# WorkLedger

Enterprise escrow DApp for small service engagements. SC6113-DEVELOPMENT OF DECENTRALIZED APPLICATIONS. Author: Liu Yanrong. Single-member group project.

## Components

Three interacting Solidity contracts: RoleRegistry, PaymentEscrow and DisputeBoard. Four roles: administrator, customer, provider and auditor. Fourteen application transaction types, exact-Wei accounting, gas estimation, signature-based login, private notes and event history.

Flask + Web3.py serves the REST API. SQLAlchemy supports SQLite locally and PostgreSQL for cloud persistence. MetaMask signs blockchain transactions; the server never holds a wallet private key.

## Local setup

```text
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
npm ci
```

Copy `.env.example` to `.env` and configure the deployment addresses and RPC. Use a cryptographically random SECRET_KEY and set PUBLIC_ORIGIN to the exact browser origin. Start with `python app.py`, then open http://127.0.0.1:5100. Linux/macOS activation is `source .venv/bin/activate`.

## Reproducible local demonstration

```text
pip install -r requirements-dev.txt
npm run chain
```

In another terminal: `python scripts/local_preview.py`. This deploys fresh local contracts, records fourteen transaction samples and seeds agreement states. It is a development-only server and connects exclusively to local chain 1337. Publicly known deterministic test accounts are never suitable for a real network. The browser test uses them through an isolated injected adapter, not a real MetaMask extension.

## Testing

```text
python -m pytest tests -q --junitxml=tests/results.xml
npx playwright install chromium
npm run test:browser
```

Browser checks require a freshly started local preview. BROWSER_PATH can select an installed Chrome executable. Run `npm run compile` after contract edits. ABI and deployment artifacts are exported to abi/ and artifacts/.

## Cloud deployment

The Render blueprint uses a Python web service and a PostgreSQL database. The database connection is provided through DATABASE_URL. The web service must not rely on SQLite on an ephemeral cloud filesystem. The free database plan has provider-defined expiry and backup limits; this is demonstration hosting, not a production availability commitment.

The deployment helper at /deploy is enabled only with ENABLE_DEPLOY_UI=true. It deploys the three contracts and binds the board in four MetaMask transactions on Sepolia. ROLEREGISTRY_ADDRESS, PAYMENTESCROW_ADDRESS and DISPUTEBOARD_ADDRESS are stored using the exact variable names in `.env.example`. The helper is disabled for normal operation. The API validates the chain and bound board at /api/status.

## Evidence

45 Python tests and 14 browser checks passed in the isolated local environment. Read measurement: 40 requests at concurrency four, all HTTP 200. Gas and optimization data are in tests/. Screenshots show local chain 1337. Public deployment evidence is recorded separately in docs/Deployment_Record.md.

## Structure

- contracts/: Solidity sources; abi/: raw ABI arrays; artifacts/: compiled bytecode.
- app.py: Flask API and database schema.
- templates/ and static/: HTML, CSS, JavaScript and local ethers bundle.
- docs/: technical report, diagrams, presentation, user manual and individual contribution.
- tests/: executable tests and recorded results.
- scripts/: compilation, local preview and report generation.

## Security boundaries

The assigned auditor can allocate disputed funds and remains assigned even if later removed from new-job eligibility. Lost auditor keys can strand disputes. Hashes do not provide confidentiality. Notes are access-controlled, not encrypted by the application. EIP-1271 contract wallets are not supported. One block is inclusion, not finality. The index rescans twelve blocks and is a cache, not a custody authority. Production use requires independent audit, operational controls and jurisdiction-specific review.

Third-party ethers code retains its MIT license in static/vendor/ETHERS-LICENSE.md.

Local Git history is supplied as `source-history.bundle`; inspect it with `git clone source-history.bundle workledger-history`. The free cloud database created for this project expires on 13 November 2026.
